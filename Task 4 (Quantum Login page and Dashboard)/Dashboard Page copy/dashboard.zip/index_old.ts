// type detail=[{
//     img:string,
//     course_name:string,
//     grade_detail:{
//         subject:string,
//             no_of_grade:number,
//             grade_increment:number
//         },
//     course_distribution_detail:
//         {
//             unit:number,
//             lesson:number,
//             topic:number
//         },
//     select_class:
//         {
//             option:string
//         },
//     student_and_validity:
//         {
//             student:number,
//             validity:string
//         }    
// } | {
//     img:string,
//     course_name:string,
//     grade_detail:{
//         subject:string,
//             no_of_grade:number,
//             grade_increment:number
//         },
//     course_distribution_detail:
//         {
//             unit:number,
//             lesson:number,
//             topic:number
//         },
//     select_class:
//         {
//             option:string
//         }
    
// }];

// var markup=`<div class="course_card1">
// <div class="course_detail">
//     <img class="course_img"src="images/images/imageMask-1.svg" alt="Acceleration Course image" />
//     <div class="course_card_detail">
//         <div class="course_name"> </div>
//         <div class="grade_detail"> <span class="card_subject_name">Physics</span>
//             <span class="seperate_partition">|</span>
//             <span class="grade">Grade <span class="no_of_grade">7</span></span>
//             <span class="grade_increment">+2</span></div>
//         <div class="course_distribution_detail"><span class="no_of_unit">4</span> Units<span class="no_of_lesson">18</span> Lessons<span class="no_of_topic">24</span> Topics</div>
//         <select class="select_class_detail" >
//             <option name="class_name_option" id="option_class_name" class="option_class_name" value="ClassB">Mr. Frank's Class B</option>
//         </select>
//         <p class="no_of_student_and_validity_wrapper"><span class="student"><span class="no_of_student">50</span> Students</span> <span class="course_validity"></span><span class="seperate_partition">|</span>21-Jan-2020 - 21-Aug-2020</span></p> 
//     </div>           
// </div>
// <div class="star_icon_wrapper">
//     <img class="star_img"src="images/icons/favourite.svg" alt="favourite icon" />
// </div>
// <div class="card_footer_icon">
//     <img class="card_footer_preview_icon"src="images/icons/preview.svg" alt="preview icon" />
//     <img class="card_footer_manage_course_icon"src="images/icons/manage%20course.svg" alt="manage course icon" />
//     <img class="card_footer_grading_icon"src="images/icons/grade%20submissions.svg"  alt="grade submission icon"/>
//     <img class="card_footer_report_icon"src="images/icons/reports.svg" alt="report icon"/>

// </div>
// </div> 

// </div>
// </div>`
// // var data;
// // fetch(`./course_card_detail.json`).then(response=>response.json()).then(response=>{
// //  data= response;
// // })
// // console.log(data)
// function getData(){
//     return fetch('./course_card_detail.json')
//         .then((response) => {
//                 return response.json()
//         })
//         .then((data) => {
                
            
                
                
//         })
//         .catch((err) => {
//                 console.log(err)
//                 alert(`Something went wrong (${err.message})`);
//         });
//     }

// // console.log( getData());
//     // let card_detail=response.json();
//     var getdata;
//     async function fetch(URL) {
//         const response = await fetch(URL);
//         var data = await response.json();
//         console.log({data});
//         const content=document.getElementsByClassName("main")[0]
//                 content.innerHTML=
//     }
    
    
//     const newData= fetch('./course_card_detail.json');
//     console.log("response "+newData)








//     // for(let i=0;i<response.length;i++){
//     //     const courseCard=document.createElement("div");
//     //     courseCard.setAttribute("class",`course_card${i+1}`);
        
//     //     const card_detail=document.createElement("div");
//     //     card_detail.setAttribute("class","card_detail");
//     //     courseCard.appendChild(card_detail);

//     //     const courseImg=document.createElement("img");
//     //     courseImg.setAttribute("src",`${response[i].img}`);
//     //     courseImg.setAttribute("class",'course_img');
//     //     courseImg.setAttribute("alt",`${response[i].name} course image`);
//     //     card_detail.appendChild(courseImg);

//     //     const courseInfo=document.createElement("div");
//     //     courseInfo.setAttribute("class",'course_card_detail')
//     //     card_detail.appendChild(courseInfo);

//     //     const courseName=document.createElement("div");
//     //     courseName.setAttribute("class")

//     // }